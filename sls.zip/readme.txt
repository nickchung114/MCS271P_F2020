Compilation requires the following files to be in the directory
  maxSAT.cpp
  timer.h
  timer.c (included in maxSAT.cpp)

The program runs fastest when the compiler optimizes it
  g++ maxSAT.cpp -O2 -o maxSAT

  (or equivalent optimization on other compilers)

Then to run
  ./maxSAT [max-sat-problem file or path to file]

The output will be a time and number of clauses satisfied
